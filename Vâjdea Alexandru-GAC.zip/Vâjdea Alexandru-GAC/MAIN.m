close all;
 
Ao=0;
A=10;
f=1000;
N=5;
RB1=15000;
RB2=5000;
RC=500;
RE=700;
beta=100;
VAl=15;
val=1;
tip=1;
proiect(Ao,A,f,N,RB1,RB2,RC,RE,beta,VAl,val,tip);
